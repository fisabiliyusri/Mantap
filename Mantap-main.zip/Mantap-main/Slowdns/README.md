# SCRIPT SLOWDNS SERVER
Install Otomatis SlowDns dnstt-server
